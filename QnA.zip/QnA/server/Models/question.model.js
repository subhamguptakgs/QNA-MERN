const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const QuestionSchema = new Schema({
    uri: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    body: {
        type: String,
        required: true
    },
    asker: {
        type: Object,
        required: true
    },
    answers: {
        type: Array,
        required: false
    },
    comments: {
        type: Array,
        required: false
    },
    likes: {
        type: Array,
        required: false
    }

}, {
    timestamps: true,
    versionKey:false
})

const Question = mongoose.model("Question", QuestionSchema);

module.exports = Question;