const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();
const Question = require('../Models/question.model');
const User = require('../Models/user.model');

router.get('/get/all', (req, res) => {
    Question.find().sort({_id: -1}).limit(100)
    .then(questions => res.json(questions))
    .catch(err => res.status(500).json(err))
})

router.get('/get/:uri', (req, res) =>{
    Question.findOne({uri: req.params.uri}, (err, question) => {
        if(err || !question) res.status(404).json("Question not found.")
        else res.json(question)
    })
})

router.post('/create', jsonParser, (req, res) => {
    const {token, title, body, asker} = req.body;
    //Validating asker
    const uri=title.toLowerCase()
    .replace(/[^\w ]+/g, '')
    .replace(/ +/g, '-');
    User.findOne({email: asker, token}, (err, user) => {
        if(err) res.status(500).json("Something went wrong.")
        else if(!user) res.status(403).json("Permission denied.")
        else{

            const newQuestion = new Question({uri,title, body, asker: user})
            newQuestion.save()
            .then(() => res.json({"message": "Success", "id": newQuestion._id}))
            .catch(err => res.status(400).json(err))
        }
    })
})

router.post('/answer', jsonParser, (req, res) => {
    const {answer, token, answerer, question} = req.body;
    //Validating answerer
    User.findOne({email: answerer, token}, (err, user) => {
        if(err) res.status(500).json("Something went wrong.")
        else if(!user) res.status(403).json("Permission denied. ")
        else{
            Question.findOne({_id: question}, (err, question) => {
                if(err || !question) res.status(500).json("Something went wrong.")
                else{
                    question.answers.push({answerer: user, answer,comments:[],likes:[]})
                    question.save()
                    .then(() => res.json({message: "Success"}))
                }
            })
        }
    })
})
router.post('/comment-question', jsonParser, (req, res) => {
    const {answer, token, answerer, question} = req.body;
    //Validating answerer
    User.findOne({email: answerer, token}, (err, user) => {
        if(err) res.status(500).json("Something went wrong.")
        else if(!user) res.status(403).json("Permission denied. ")
        else{
            Question.findOne({_id: question}, (err, question) => {
                if(err || !question) res.status(500).json("Something went wrong.")
                else{
                    question.comments.push({answerer: user, answer})
                    question.save()
                    .then(() => res.json({message: "Success"}))
                }
            })
        }
    })
})
router.post('/comment-answer', jsonParser, (req, res) => {
    const {answer, token, answerer, question,index} = req.body;
    //Validating answerer
    console.log(index);
    User.findOne({email: answerer, token}, (err, user) => {
        if(err) res.status(500).json("Something went wrong.")
        else if(!user) res.status(403).json("Permission denied. ")
        else{
            Question.findOne({_id: question}, (err, question1) => {
                console.log(question,question1);
                if(err || !question1) 
                {
                    console.log(err);
                    res.status(500).json("Something went wrong.")
                }
                else{
                    Question.replaceOne({uri: question1.uri},question1.answers[parseInt(index)].comments.push({answerer: user, answer}));
                    question1.save()
                    .then(() => res.json({message: "Success"}))
                }
            })
        }
    })
})
router.post('/like-question', jsonParser, (req, res) => {
    const { token, answerer, question} = req.body;
    //Validating answerer
    User.findOne({email: answerer, token}, (err, user) => {
        if(err) res.status(500).json("Something went wrong.")
        else if(!user) res.status(403).json("Permission denied. ")
        else{
            Question.findOne({_id: question}, (err, question) => {
                if(err || !question) res.status(500).json("Something went wrong.")
                else{
                    question.likes.push({answerer: user})
                    question.save()
                    .then(() => res.json({message: "Success"}))
                }
            })
        }
    })
})
router.post('/like-answer', jsonParser, (req, res) => {
    const { token, answerer, question,index} = req.body;
    //Validating answerer
    User.findOne({email: answerer, token}, (err, user) => {
        if(err) res.status(500).json("Something went wrong.")
        else if(!user) res.status(403).json("Permission denied. ")
        else{
            Question.findOne({_id: question}, (err, question) => {
                if(err || !question) res.status(500).json("Something went wrong.")
                else{
                    question.answers[parseInt(index)].likes.push({answerer: user})
                    question.save()
                    .then(() => res.json({message: "Success"}))
                }
            })
        }
    })
})
module.exports = router;